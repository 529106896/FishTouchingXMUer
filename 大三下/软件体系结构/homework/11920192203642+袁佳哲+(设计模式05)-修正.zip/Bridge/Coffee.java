package Bridge;

public abstract class Coffee {
    CoffeeImp coffeeImp;
    public void setCoffeeImp() {
        this.coffeeImp = CoffeeImpSingleton.getCoffeeImp();
//        this.coffeeImp = coffeeImp;
    }
    public CoffeeImp getCoffeeImp() {
        return this.coffeeImp;
    }
    public abstract void pourCoffee();
}
