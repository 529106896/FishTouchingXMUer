package Bridge;

public abstract class CoffeeImp {
    public abstract void pourCoffeeImp();
}
