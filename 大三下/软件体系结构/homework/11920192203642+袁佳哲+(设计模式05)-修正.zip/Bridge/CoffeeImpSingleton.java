package Bridge;

public class CoffeeImpSingleton {
    private static CoffeeImp coffeeImp;
    public CoffeeImpSingleton(CoffeeImp coffeeImp) {
        this.coffeeImp = coffeeImp;
    }
    public static CoffeeImp getCoffeeImp() {
//        System.out.println(coffeeImp);
        return coffeeImp;
    }

    public void setCoffeeImp(CoffeeImp coffeeImp) {
        this.coffeeImp = coffeeImp;
    }
}
