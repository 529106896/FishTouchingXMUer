package Bridge;

public class FragrantCoffeeImp extends CoffeeImp {
    FragrantCoffeeImp() {
    }
    public void pourCoffeeImp() {
        System.out.println("什么也不加的清香咖啡");
    }
}
