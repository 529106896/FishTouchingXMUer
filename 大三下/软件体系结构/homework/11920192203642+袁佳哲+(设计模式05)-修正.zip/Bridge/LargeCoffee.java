package Bridge;

public class LargeCoffee extends Coffee {
    public LargeCoffee() {
        setCoffeeImp();
    }
    public void pourCoffee() {
        CoffeeImp coffeeImp = this.getCoffeeImp();
        for (int i=0; i<5; i++) {
            coffeeImp.pourCoffeeImp();
        }
        System.out.println("倒了5次，这是大杯");
    }
}
