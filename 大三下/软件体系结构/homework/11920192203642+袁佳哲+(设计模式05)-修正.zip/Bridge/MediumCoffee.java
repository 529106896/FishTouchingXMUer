package Bridge;

public class MediumCoffee extends Coffee {
    public MediumCoffee() {
        setCoffeeImp();
    }
    public void pourCoffee() {
        CoffeeImp coffeeImp = this.getCoffeeImp();
        for (int i=0; i<2; i++) {
            coffeeImp.pourCoffeeImp();
        }
        System.out.println("倒了2次，这是中杯");
    }
}
