package Bridge;

public class SmallCoffee extends Coffee{
    public SmallCoffee() {
        setCoffeeImp();
    }
    public void pourCoffee() {
        CoffeeImp coffeeImp = this.getCoffeeImp();
        coffeeImp.pourCoffeeImp();
        System.out.println("倒了1次，这是小杯");
    }
}
