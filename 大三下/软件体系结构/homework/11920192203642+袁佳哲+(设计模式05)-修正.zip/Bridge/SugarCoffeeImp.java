package Bridge;

public class SugarCoffeeImp extends CoffeeImp{
    public SugarCoffeeImp(){}

    @Override
    public void pourCoffeeImp() {
        System.out.println("珈乐糖的咖啡，很甜");
    }
}
