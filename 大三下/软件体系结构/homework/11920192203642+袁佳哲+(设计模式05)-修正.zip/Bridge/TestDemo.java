package Bridge;

public class TestDemo {
    public static void main(String [] args) {
        // 加牛奶
        CoffeeImpSingleton coffeeImpSingleton = new CoffeeImpSingleton(new MilkCoffeeImp());

        // 中杯，加牛奶
        MediumCoffee mediumCoffee = new MediumCoffee();
        mediumCoffee.pourCoffee();

        // 大杯，加牛奶
        LargeCoffee largeCoffee = new LargeCoffee();
        largeCoffee.pourCoffee();

        // 什么都不加，清香
        CoffeeImpSingleton coffeeImpSingleton1 = new CoffeeImpSingleton(new FragrantCoffeeImp());

        // 中杯，清香
        MediumCoffee mediumCoffee1 = new MediumCoffee();
        mediumCoffee1.pourCoffee();

        // 大杯，清香
        LargeCoffee largeCoffee1 = new LargeCoffee();
        largeCoffee1.pourCoffee();

        // 加糖
        CoffeeImpSingleton coffeeImpSingleton2 = new CoffeeImpSingleton(new SugarCoffeeImp());

        // 小杯，加糖
        SmallCoffee smallCoffee = new SmallCoffee();
        smallCoffee.pourCoffee();

        // 大杯，加糖
        LargeCoffee largeCoffee2 = new LargeCoffee();
        largeCoffee2.pourCoffee();
    }
}
