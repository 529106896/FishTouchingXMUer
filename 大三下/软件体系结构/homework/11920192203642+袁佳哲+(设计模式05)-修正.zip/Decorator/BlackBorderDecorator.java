package Decorator;

public class BlackBorderDecorator extends ComponentDecorator{
    public BlackBorderDecorator(Component component) {
        super(component);
        System.out.println("Add Black Border");
    }

    public void setBlackBorder() {
        System.out.println("Set Black Border");
    }

//    @Override
//    public void display() {
//        this.setBlackBorder();
//        super.display();
//    }
}
