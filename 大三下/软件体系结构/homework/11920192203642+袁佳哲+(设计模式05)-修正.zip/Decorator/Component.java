package Decorator;

public abstract class Component {
    public abstract void display();
}
