package Decorator;

public class ScrollBarDecorator extends ComponentDecorator{
    public ScrollBarDecorator(Component component) {
        super(component);
        System.out.println("Add Scroll Bar");
    }

//    @Override
//    public void display() {
//        this.setScrollBar();
//        super.display();
//    }

    public void setScrollBar() {
        System.out.println("Set Scroll Bar");
    }

    public void setNewScrollBar() {
        System.out.println("Set Scroll Bar");
    }
}
