package Decorator;

public class TestDemo {
    public static void main(String[] args) {
        /**
         * 透明装饰模式：
         * 透明装饰模式中要求客户端完全针对抽象编程
         * 要求客户端程序不应该将对象声明为具体构件类型或具体装饰类型
         * 而应该全部声明为抽象构件类型
         *
         * 优点是可以多次装饰
         * 缺点是无法单独调用装饰器的独特功能
         */
        Component window = new Window();
        Component component1 = new BlackBorderDecorator(window);  // 使用抽象构件类型
        Component component2 = new ScrollBarDecorator(component1);  // 多次装饰
//        component2.setScrollBar()  无法单独调用功能
        component2.display();

        System.out.println("———————————separator line—————————————");

        /**
         * 半透明装饰模式：
         * 用具体装饰类型来定义装饰之后的对象，可单独调用装饰器的功能
         *
         * 如果我们后续需要为装饰器添加功能，那么半透明模式将会更加适合
         *
         * 缺点是无法实现多次装饰
         */

        Component listbox = new ListBox();
        BlackBorderDecorator blackBorderDecorator = new BlackBorderDecorator(listbox);
        blackBorderDecorator.setBlackBorder();
        blackBorderDecorator.display();

        ScrollBarDecorator scrollBarDecorator = new ScrollBarDecorator(blackBorderDecorator);
        scrollBarDecorator.display();  // 之前的装饰会丢失
    }
}
