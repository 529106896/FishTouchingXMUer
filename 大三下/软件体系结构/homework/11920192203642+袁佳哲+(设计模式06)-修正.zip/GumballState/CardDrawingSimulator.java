package GumballState;

public class CardDrawingSimulator {
    int count = 0;
    int stoneCount = 0;
    State state;
    State hasDaBaoDi;
    State hasXiaoBaoDi;
    State noXiaoBaoDi;

    public CardDrawingSimulator(int hasDrawnCount) {
        hasDaBaoDi = new HasDaBaoDi(this);
        hasXiaoBaoDi = new HasXiaoBaoDi(this);
        noXiaoBaoDi = new NoXiaoBaoDi(this);

        this.count = hasDrawnCount;
        state = noXiaoBaoDi;

        if (hasDrawnCount >= 90 && hasDrawnCount < 180) {
            state = hasXiaoBaoDi;
        } else if (hasDrawnCount >= 180) {
            state = hasDaBaoDi;
        }
    }

    public void doOneTime() {
        System.out.println("——————————————————");
        System.out.println("当前状态：" + this.state.getStatus());
        System.out.println("当前已抽：" + this.count);
        System.out.println("当前原石数量：" + this.stoneCount);
        if (this.stoneCount <= 160) {
            System.out.println("原石不足！请先充值或锄大地！");
            return;
        }
        System.out.println("你选择抽一发，正在播放抽卡动画");
        this.count++;
        this.stoneCount -= 160;
        if (this.count == 90) {
            System.out.println("到达小保底！你歪了刻晴！");
            state = hasXiaoBaoDi;
        } else if(this.count == 180) {
            System.out.println("到达大保底！强娶UP角色！");
            state = hasDaBaoDi;
        } else {
            state.doOneTime();
        }
    }

    public void doTenTimes() {
        System.out.println("——————————————————");
        System.out.println("当前状态：" + this.state.getStatus());
        System.out.println("当前已抽：" + this.count);
        System.out.println("当前原石数量：" + this.stoneCount);
        if (this.stoneCount <= 1600) {
            System.out.println("原石不足！请先充值或锄大地！");
            return;
        }
        System.out.println("你选择抽十连，正在播放抽卡动画");
        this.count += 10;
        this.stoneCount -= 1600;
        if (this.count >= 90 && this.count <= 180) {
            System.out.println("已小保底！你歪了刻晴！");
            state = hasXiaoBaoDi;
        } else if(this.count >= 180) {
            System.out.println("到达大保底！强娶UP角色！");
            state = hasDaBaoDi;
        } else {
            state.doTenTimes();
        }
    }

    public void recharge328() {
        System.out.println("——————————————————");
        System.out.println("当前状态：" + this.state.getStatus());
        System.out.println("当前已抽：" + this.count);
        System.out.println("当前原石数量：" + this.stoneCount);
        System.out.println("你选择充值328，正在支付");
        this.stoneCount += 3280;
        state.recharge328();
    }

    public void recharge648() {
        System.out.println("——————————————————");
        System.out.println("当前状态：" + this.state.getStatus());
        System.out.println("当前已抽：" + this.count);
        System.out.println("当前原石数量：" + this.stoneCount);
        System.out.println("你选择充值648，正在支付");
        this.stoneCount += 6480;
        state.recharge648();
    }

    public void playWholeDay() {
        System.out.println("——————————————————");
        System.out.println("当前状态：" + this.state.getStatus());
        System.out.println("当前已抽：" + this.count);
        System.out.println("当前原石数量：" + this.stoneCount);
        System.out.println("你选择锄大地，锄完后将获得2000原石");
        this.stoneCount += 2000;
        state.playWholeDay();
    }

    public void getStatus() {
        System.out.println("——————————————————");
        System.out.println("你选择查看当前UP池抽卡状态：");
        System.out.println("当前状态：" + this.state.getStatus());
        System.out.println("当前已抽：" + this.count);
        System.out.println("当前原石数量：" + this.stoneCount);
    }

    public int getCount() {
        return count;
    }

    public int getStoneCount() {
        return stoneCount;
    }

    public State getState() {
        return state;
    }

    public State getHasDaBaoDi() {
        return hasDaBaoDi;
    }

    public State getHasXiaoBaoDi() {
        return hasXiaoBaoDi;
    }

    public State getNoXiaoBaoDi() {
        return noXiaoBaoDi;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setStoneCount(int stoneCount) {
        this.stoneCount = stoneCount;
    }

    public void setState(State state) {
        this.state = state;
    }
}
