package GumballState;

public class HasDaBaoDi implements State {

    CardDrawingSimulator cardDrawingSimulator;

    public HasDaBaoDi(CardDrawingSimulator cardDrawingSimulator) {
        this.cardDrawingSimulator = cardDrawingSimulator;
    }

    @Override
    public void doOneTime() {
        System.out.println("有了大保底还要抽一发，继续继续");
    }

    @Override
    public void doTenTimes() {
        System.out.println("有了大保底还要抽十连，是个氪佬");
    }

    @Override
    public void recharge328() {
        System.out.println("有了大保底还在氪328，是个狠人");
    }

    @Override
    public void recharge648() {
        System.out.println("有了大保底还在氪648，可以可以");
    }

    @Override
    public void playWholeDay() {
        System.out.println("有了大保底还要锄大地，肝帝肝帝");
    }

    @Override
    public String getStatus() {
        return "已有大保底";
    }
}
