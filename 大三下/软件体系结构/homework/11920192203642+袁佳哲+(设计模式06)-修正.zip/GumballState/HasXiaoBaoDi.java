package GumballState;

public class HasXiaoBaoDi implements State {
    CardDrawingSimulator cardDrawingSimulator;

    public HasXiaoBaoDi(CardDrawingSimulator cardDrawingSimulator) {
        this.cardDrawingSimulator = cardDrawingSimulator;
    }

    @Override
    public void doOneTime() {
        System.out.println("有了小保底还要抽一发，小保底歪了吧哈哈哈");
    }

    @Override
    public void doTenTimes() {
        System.out.println("有了小保底还要抽十连，小保底歪了吧哈哈哈");
    }

    @Override
    public void recharge328() {
        System.out.println("谢谢充值328！祝您下一发就出货，马上就大保底了！");
    }

    @Override
    public void recharge648() {
        System.out.println("谢谢充值648！祝您下一发就出货，马上就大保底了！");
    }

    @Override
    public void playWholeDay() {
        System.out.println("继续锄大地！马上就大保底了！");
    }

    @Override
    public String getStatus() {
        return "已有小保底，但歪了刻晴";
    }
}
