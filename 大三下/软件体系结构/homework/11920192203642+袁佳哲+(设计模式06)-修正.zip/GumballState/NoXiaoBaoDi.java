package GumballState;

public class NoXiaoBaoDi implements State {

    CardDrawingSimulator cardDrawingSimulator;

    public NoXiaoBaoDi(CardDrawingSimulator cardDrawingSimulator) {
        this.cardDrawingSimulator = cardDrawingSimulator;
    }

    @Override
    public void doOneTime() {
        System.out.println("加油加油，小保底未出，单抽碰运气！");
    }

    @Override
    public void doTenTimes() {
        System.out.println("加油加油，小保底未出，十连碰运气！");
    }

    @Override
    public void recharge328() {
        System.out.println("有钱，直接砸328！硬吃小保底！");
    }

    @Override
    public void recharge648() {
        System.out.println("有钱，直接砸648！硬吃小保底！");
    }

    @Override
    public void playWholeDay() {
        System.out.println("不氪了，为了抽卡我要肝一天！");
    }

    @Override
    public String getStatus() {
        return "未到小保底";
    }
}
