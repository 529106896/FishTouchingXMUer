package GumballState;

public interface State {
    void doOneTime();
    void doTenTimes();
    void recharge328();
    void recharge648();
    void playWholeDay();
    String getStatus();
}
