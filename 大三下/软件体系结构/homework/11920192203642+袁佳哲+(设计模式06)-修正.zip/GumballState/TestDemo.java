package GumballState;

public class TestDemo {
    public static void main(String[] args) {
        CardDrawingSimulator cardDrawingSimulator = new CardDrawingSimulator(80);
        cardDrawingSimulator.getStatus();
        cardDrawingSimulator.recharge648();
        cardDrawingSimulator.getStatus();
        cardDrawingSimulator.doTenTimes();
        cardDrawingSimulator.getStatus();
    }
}
