package Obersever;

public class Client {
    public static void main(String[] args) throws InterruptedException {
        RandomNumberGenerator randomNumberGenerator = new RandomNumberGenerator();
        RandomNumberObserver randomNumberObserver = new RandomNumberObserver();
        randomNumberGenerator.addObserver(randomNumberObserver);
        randomNumberGenerator.execute();
    }
}
