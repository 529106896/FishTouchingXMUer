package Obersever;

import java.util.Observable;
import java.util.Random;

public class RandomNumberGenerator extends Observable {
    private Random random = new Random();
    private int number;
    public int getNumber() {
        return number;
    }
    public void execute() throws InterruptedException {
        for (int i=0; i<10; i++) {
            number = random.nextInt(50);
            super.setChanged();
            super.notifyObservers();
            Thread.sleep(100);
        }
    }
}
