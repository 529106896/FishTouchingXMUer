#include <iostream>

using namespace std;

int main()
{
    cout << "Combining the letters ‘H’, ‘e’, ‘l’, ‘l’, ‘o’ will make the word “Hello”." << endl;

    system("pause");
    return 0;
}